import jwt from 'jsonwebtoken';

export const verifyToken = (req, res, next) => {
    let token = req.headers.authorization;

    if(!token){// if its empty u get an 401 error
        return res.status(401).json({ error: "Token not provided/empty"});
    }

    token = token.split(" ")[1]; // split the token for the jwt verify

    try {   
        const {email} = jwt.verify(token, process.env.JWT_PASSWORD);
        req.email = email;

        next();
    }catch(error){
        console.log(error);
        return res.status(403).json({ error: "Token Invalid/Expired"});
    }
}
