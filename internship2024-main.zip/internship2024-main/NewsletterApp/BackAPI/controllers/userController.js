import users  from '../models/usersModel.js';

import jwt from "jsonwebtoken";
import 'dotenv/config';
import bcryptjs from 'bcryptjs';
import nodemailer from "nodemailer";

// controller to register users
const register = async (req, res) => {
    try {
        console.log(req.body);
        const { user, email, passw } = req.body;
        // If one of the values is missing, it returns an error message.
        if (!user || !email || !passw){
            return res.status(400).json({ok:false, msg:"One of the values is missing (user, email, password)..."});
        }
        // if the email already exists, it returns an error message.
        const usere = await users.findOne({where:{email: email}})
        if (usere) {
            return res.status(409).json({ ok: false, msg: "Email already exists" })
        }
        //Encrypting password
        const salt = await bcryptjs.genSalt(10);
        const hashedContrasena = await bcryptjs.hash(passw, salt);  // I LOVE what you did here!
        const newUser = await users.create({
            username: user,
            email, 
            passw: hashedContrasena,
            dated: new Date(),
            idrol: 1
        });

        const token = jwt.sign({email: newUser.email},
            process.env.JWT_PASSWORD,
            {
                expiresIn: "1h"
            }
        );
        return res.status(201).json({ok:true, msg: token});
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}

// /api/v1/users/login
const login = async (req, res) =>{
    try {
        const { email, passw } = req.body; // we request the password and email

        if(!email || !passw){ // we validate that the fields have been filled 
            return res.status(400).json({ error: "data is missing: email or password" });
        }
        //  'user' variable that will contain the email and password data for comparison
        const user = await users.findOne({where:{email: email}})

        if(!user){// if it doesn't, error
            return res.status(404).json({ error: "Email doesnt exist" });
        }

        //compare the passwords of the login with the database
        const isMatch = await bcryptjs.compare(passw, user.passw);
        if(!isMatch){// if they dont match error
            return res.status(401).json({ error: "Passwords dont match" });
        }
        const payload = {
            nombre: user.user,
            email: user.email,
        };
        //if password and email match, the token is generated
        const token = jwt.sign(payload,
            process.env.JWT_PASSWORD,
            { expiresIn: "1h" }
        );

        // send the email
        console.log("acaaaa", process.env, process.env.EMAIL_USER)
        try {
            const transport = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: process.env.EMAIL_USER,
                    pass: process.env.EMAIL_PASS
                }
            });
            
            var verificationCode = '';
            for (let i = 0; i < 6; i++) {
                const numeroR = Math.floor(Math.random() * 9) + 1;
                verificationCode += numeroR.toString();
            }

            const sendOptions = {
                from: process.env.EMAIL_USER,
                to: email,
                subject: 'your verification code is: ' + verificationCode
            };
            await transport.sendMail(sendOptions);
            
        } catch (error) {
            console.log('Error sending email:', error);
            return res.status(500).json({ ok: false, msg: 'Error sending email' });
        }
        const verificationCodeHash = await bcryptjs.hash(verificationCode, 10); 
        return res.json({ ok: true, msg: token, codigo2P: verificationCodeHash });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}


const compare2StepCode = async (req, res) =>{
    try {
        const { checker, localV } = req.body; // We request the code 
        if(!checker){ // We validate that the fields have been filled
            return res.status(400).json({ error: "Data is missing" });
        }
        const verificationCodeHasheado = localV; 
        const isMatch = await bcryptjs.compare(checker, verificationCodeHasheado);
        
        if(!isMatch){// Error if they arent the same
            return res.status(401).json({ error: "The 2 step verification code does not match" });
        }
        return res.json({ ok: true });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}
const profile = async (req, res) =>{
    try{
        const usere = await users.findOne({where:{email: req.email}})
        
        return res.json({ok: true, msg: usere});
    } catch (error){
        console.log(error);
        return res.status(500).json({ok:false, msg: "Error server"});
    }
}

export const UserController = {
    register,
    login,
    profile,
    compare2StepCode
}
