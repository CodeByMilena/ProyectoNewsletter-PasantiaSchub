import {Router} from "express";
//import { article } from "../models-P/articleModel.js";
import article  from '../models/articlesModel.js';
import newsletter  from '../models/newslettersModel.js';
import { Op, Sequelize } from "sequelize";

const router  = Router();

const addArticle = async (req, res) =>{
    try{
        const {title, summary, imagen, author, paglink, creationdate} = req.body;
        console.log(req.body);
        const newArticle = await article.create({title, summary, imagen, author, paglink, creationdate})
        return res.status(201).json({ok:true, msg:"Article added successfully"});
    }catch(error){
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: req.body
        });
    }
}

const extractArticles = async (req, res) =>{
    try{
        const articles = await article.findAll();
        return res.status(201).json({ok:true, msg:articles});
    }catch(error){
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}

const addNewsletterMaker = async (req, res) =>{
    try{
        const {idReq} = req.query;
        const articleById = await article.findOne({where: {id: idReq}});
        return res.status(201).json({ok:true, msg:articleById});
    }catch(error){
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}
const deleteArticle = async (req, res) =>{
    try{
        const {id} = req.query;
        const artNewsEdit = await newsletter.update(
            {
                id_art1: Sequelize.literal(`CASE WHEN id_art1 = ${id} THEN NULL ELSE id_art1 END`),
                id_art2: Sequelize.literal(`CASE WHEN id_art2 = ${id} THEN NULL ELSE id_art2 END`),
                id_art3: Sequelize.literal(`CASE WHEN id_art3 = ${id} THEN NULL ELSE id_art3 END`),
                id_art4: Sequelize.literal(`CASE WHEN id_art4 = ${id} THEN NULL ELSE id_art4 END`),
                id_art5: Sequelize.literal(`CASE WHEN id_art5 = ${id} THEN NULL ELSE id_art5 END`),
            },
            {
                where:{
                    [Op.or]: [
                        { id_art1: id },
                        { id_art2: id },
                        { id_art3: id },
                        { id_art4: id },
                        { id_art5: id },
                      ],
                },
            }
        )
        const articleDeleted = await article.destroy({where: {id: id}});
        return res.status(201).json({ok:true, msg:articleDeleted});
    }catch(error){
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}

export const articles = {
    addArticle,
    extractArticles,
    addNewsletterMaker,
    deleteArticle
}
