import { decodeAR } from '../models/decodeJWT.js';
import newsletter from '../models/newslettersModel.js';
import users from '../models/usersModel.js';
import nodemailer from "nodemailer";
import { Router } from "express";


const registerNewsletter = async (req, res) => {
    try {
        console.log(req.body);
        const { issue, id_art1, id_art2, id_art3, id_art4, id_art5, staten, creator } = req.body;

        if (!issue || !staten || !creator) {
            return res.status(400).json({ ok: false, msg: "One of the following values (issue, state, creator)..." });
        }
        //decodes token
        const emailDesen = decodeAR.decodeJWT(creator);

        // console.log(emailDesen.email)
        let creatorD;
        try {
            creatorD = await users.findOne({ where: { email: emailDesen.email } });

            if (!creatorD) {
                return res.status(404).json({ ok: false, msg: "A user with the provided email was not found" });
            }
        } catch (error) {
            console.error('Error at searching the user:', error);
            return res.status(500).json({ ok: false, msg: 'Error at searching the user.' });
        }

        const newNewsletterModel = await newsletter.create({
            issue,
            id_art1,
            id_art2,
            id_art3,
            id_art4,
            id_art5,
            staten,
            date: new Date(),
            creator: creatorD.id
        });

        return res.status(201).json({ ok: true, msg: newNewsletterModel, ms: "Newsletter registered successfully" });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            ok: false,
            msg: 'Server error.'
        });
    }
};

const editAlterTable = async (req, res) => {
    try {
        console.log(req.body);
        const { id, id_art1, id_art2, id_art3, id_art4, id_art5 } = req.body;

        const newNewsletterModel = await newsletter.update({ id_art1, id_art2, id_art3, id_art4, id_art5 }, { where: { id: id } });

        return res.status(201).json({ ok: true, msg: "Edited succesfully" });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}
const extractNewssletters = async (req, res) => {
    try {
        const newsletters = await newsletter.findAll();
        return res.status(201).json({ ok: true, msg: newsletters });
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}
const searchArticlesByID = async (req, res) => {
    try {
        const { id } = req.query;
        if (id === null) {
            console.log("invalid ID:", id);

        } else {
            const newsletters = await newsletter.findOne({ where: { id: id } });
            return res.status(200).json({ ok: true, msg: newsletters });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
};

const searchAuthorID = async (req, res) => {
    try {
        const { id } = req.query;
        if (id === null) {
            console.log("invalid ID:", id);
        } else {
            const author = await newsletter.findOne({ where: { id: id } });
            const nameAuthor = await users.findOne({ where: { id: author.creator } })

            return res.status(200).json({ ok: true, msg: nameAuthor });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
};

const deleteNewsletter = async (req, res) => {
    try {
        const { id } = req.query;
        const newsletters = await newsletter.destroy({ where: { id: id } });

        return res.status(201).json({ ok: true, msg: "Nesletter deleted succesfully" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}
//The idea is sending this endpoint, take it to localStorage and show it
const editNewsletter = async (req, res) => {
    try {
        const { id } = req.query;
        if (id === null) {
            console.log("invalid ID:", id);
        } else {
            const newsletters = await newsletter.findOne({ where: { id: id } });
            const articulosIDS = {
                id_art1: newsletter.id_art1,
                id_art2: newsletter.id_art2,
                id_art3: newsletter.id_art3,
                id_art4: newsletter.id_art4,
                id_art5: newsletter.id_art5
            }
            let ArticlesA = []
            for (const ArticleID in articulosIDS) {
                if (articulosIDS.hasOwnProperty(ArticleID)) { //Used this to verifiy if property is object, i could also parse the object to array and go through it with for each but i prefer this -l
                    //console.log(newsletters[ArticleID])
                    //  const articulo = await article.findOne({where:{id: newsletters[ArticleID]}});
                    ArticlesA.push(newsletters[ArticleID])
                }
            }
            return res.status(200).json({ ok: true, msg: ArticlesA });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}

const changeState = async (req, res) => {
    try {
        const { id } = req.query;
        const newsletters = await newsletter.update(
            { staten: 1 },
            { where: { id: id } })

        //const newsletter = await NewsletterModel.replaceState({id});
        const useri = process.env.EMAIL_USER;

        const transport = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: useri,
                pass: process.env.EMAIL_PASS
            }
        });
        /*emailsNews.forEach(async user => {
            const sendOptions = {
                from: useri, 
                to: user.email,
                subject: 'testing hello'
            };
            await transport.sendMail(sendOptions);

        });*/

        return res.status(201).json({ ok: true, msg: "State changed successfully" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            ok: false,
            msg: 'Error server'
        });
    }
}


export const NewsletterController = {
    registerNewsletter,
    extractNewssletters,
    searchArticlesByID,
    deleteNewsletter,
    editNewsletter,
    editAlterTable,
    changeState,
    searchAuthorID
}
