--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: article; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.article (
    id integer NOT NULL,
    title character varying(150),
    summary text,
    author character varying(150),
    creationdate date,
    imagen text,
    paglink text
);


ALTER TABLE public.article OWNER TO postgres;

--
-- Name: article_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.article_id_seq OWNER TO postgres;

--
-- Name: article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.article_id_seq OWNED BY public.article.id;


--
-- Name: newsletters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsletters (
    id integer NOT NULL,
    issue character varying(40),
    id_art1 integer,
    id_art2 integer,
    id_art3 integer,
    id_art4 integer,
    id_art5 integer,
    staten integer,
    creator integer,
    date date
);


ALTER TABLE public.newsletters OWNER TO postgres;

--
-- Name: newsletters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.newsletters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.newsletters_id_seq OWNER TO postgres;

--
-- Name: newsletters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.newsletters_id_seq OWNED BY public.newsletters.id;


--
-- Name: states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.states (
    id integer NOT NULL,
    namestate character varying(50),
    public boolean
);


ALTER TABLE public.states OWNER TO postgres;

--
-- Name: states_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.states_id_seq OWNER TO postgres;

--
-- Name: states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.states_id_seq OWNED BY public.states.id;

-- Name: client; Type: TABLE; Schema: public; Owner: postgres
CREATE TABLE public.client (
    id_client SERIAL,
    name VARCHAR(100),
    surname VARCHAR(100),
    email VARCHAR(100),
    PRIMARY KEY (id_client)
);

ALTER TABLE public.client OWNER TO postgres;
--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    user character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    passw character varying(255) NOT NULL,
    dated date,
    idrol integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: article id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article ALTER COLUMN id SET DEFAULT nextval('public.article_id_seq'::regclass);


--
-- Name: newsletters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters ALTER COLUMN id SET DEFAULT nextval('public.newsletters_id_seq'::regclass);


--
-- Name: states id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states ALTER COLUMN id SET DEFAULT nextval('public.states_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.article (id, title, summary, author, creationdate, imagen, paglink) FROM stdin;
91	North Korean Group Collaborates with Play Ransomware in Significant Cyber Attack	 A high-severity security flaw has been disclosed in the LiteSpeed Cache plugin for WordPress that could allow an unauthenticated threat actor to elevate their privileges and perform malicious actions . The vulnerability, tracked as CVE-2024-50550 (CVSS score: 8.1), has been addressed in version 6.5.2 of the plugin . It stems from the use of a weak security hash check that could be brute-forced by a bad actor .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgY8LAsTysxOLp2_jKtDmZCnUZ4CCOpLkKu9CN1kD1nohCJhc9gDXU-hXOwCXP6gFvC-LUjC_t2PtSSGvAtJKA1fes8gsCzuR1Xs5uN6mrrIMPWx1riBnXSwESbcQEz5chjyrdJURZy2ckBFmDDhzkusdE3WnA1VOlMm_P1dKHSNzCnNVlSKxkRKdO2tKLU/s728-rw-e365/paynow.png	https://thehackernews.com/2024/10/north-korean-group-collaborates-with.html
92	Researchers Uncover Python Package Targeting Crypto Wallets with Malicious Code	 Threat actors linked to North Korea have been implicated in a recent incident that deployed a known ransomware family called Play . The activity, observed between May and September 2024, has been attributed to a threat actor tracked as Jumpy Pisces, which is also known as Andariel, APT45, DarkSeoul, Nickel Hyatt, Onyx Sleet, Operation Troy, Silent Chollima, and Stonefly . The development is a sign that North Korean threat actors could stage more widespread ransomware attacks .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjqyNGfwG8y-bN2mGRe0dRlWQk77HWdEAiAqzPxJy0RxO0f_3i-dirfPcBDIlehgM6AUsA_LA2JAKuZTMgvlMNt290G5yJc9Wy_bKso4XOkpG4smVopDaRj4xbmLacVYhJh4gjRTrjtlcSfQvHG8vhfMFtF_nlOo0yMcno-cQuq_e33dLCVlWmxmQt6D3wY/s728-rw-e365/python.png	https://thehackernews.com/2024/10/researchers-uncover-python-package.html
93	Permiso State of Identity Security 2024: A Shake-up in Identity Security Is Looming Large	 The package, named "CryptoAITools," is said to have been distributed via both Python Package Index (PyPI) and bogus GitHub repositories . It was downloaded over 1,300 times before being taken down from PyPI . The malware is designed to unleash its malicious behavior immediately after installation through code injected into its "init__.py" file . Present within the code is a helper functionality that's responsible for downloading and executing additional payloads, thereby kicking-off a multi-stage infection process . The primary goal is to gather any data that could aid the attacker in stealing cryptocurrency assets .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi1o9RF0vkpUckVXcHobyeZeKsvAWj4UQtQHoJ5iLULlGJi-2NysdoiGRcci-5-4BrG8VTYJQcjnGUNiGBs34BXAi0b4jZfdlVmtk3Wj8BHyIDYStpLKoh28cxm8K8h1JzbSrNx6AaKq1M0QbM0Gm1lYstQSvpGbbTzqckmSxRyGApeFlXoQLR8Y-jBeOW-/s728-rw-e365/main.png	https://thehackernews.com/2024/10/permiso-state-of-identity-security-2024.html
94	Researchers Uncover Vulnerabilities in Open-Source AI and ML Models	 Identity security is front, and center given all the recent breaches that include Microsoft, Okta, Cloudflare and Snowflake . Organizations are starting to realize that a shake-up is needed in terms of the way we approach identity security both from a strategic but also a technology vantage point . Social engineering-based attacks continue to be a pervasive threat to organizations . Human identities are seen as the riskiest, with employees at the top of the list .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj4log9lUju1qw-hJ6Up2aTEx86Rf9y0Qx_PYbRgPyMxkh5vB8fosPhNRa-FBe6cmvaunpivwf3mijkR-njoPCw4DPS5-0FBe_I0JfjvVIw5Tpv0BwtSRZ_8owSyN7Oyf-xywWFjKJgQsKI29EaUn5Y-OoHtMWjxK3xQS_5Jo8dOmCHSzSs79pSBoSBJL6P/s728-rw-e365/ai.png	https://thehackernews.com/2024/10/researchers-uncover-vulnerabilities-in.html
95	A Sherlock Holmes Approach to Cybersecurity: Eliminate the Impossible with Exposure Validation	 A little over three dozen security vulnerabilities have been disclosed in various open-source artificial intelligence (AI) and machine learning (ML) models . The flaws, identified in tools like ChuanhuChatGPT, Lunary, and LocalAI, have been reported as part of Protect AI's Huntr bug bounty platform . Some of which could lead to remote code execution and information theft .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiUX-NqqYivGc9ZW5qBtOrfxdD2YZVCELIhxEXZbe1v90nP1dmW6RZE3zBTNxtCrnMYXTraxsTHA60KMZf66zaK9ZSqbcxz5k1HldavcugB7tJ76auJzFxSP7y0LfUQb8xHUdshD5UfX8IwrWRX5XtNZwIA5O2AT54JAo1eDaBUP_2vb_MqGjakJ4tLMAE/s728-rw-e365/main.png	https://thehackernews.com/2024/10/a-sherlock-holmes-approach-to.html
96	GitOps as a Security & Compliance Enabler	 Exposure validation (sometimes called Adversarial Exposure Validation) enables teams to concentrate on the most significant issues and minimize distractions . Not all vulnerabilities are created equal, and many can be mitigated by controls already in place or may not be unexploitable in your environment . Automated tools easily integrate with existing systems with minimal disruption to current processes .	Ben Rodríguez	2024-10-31	https://schub.cloud/web/image/249753-e0096082/Blog-JULIO_Miniatura-blog.png	https://schub.cloud/blog/blog-1/gitops-as-a-security-compliance-enabler-43
97	The AI Risk Repository	 In the rapidly evolving landscape of technology, maintaining robust security and compliance frameworks is a top priority for any organization . By utilizing GitOps methodologies, companies can significantly enhance their security posture and ensure compliance with regulatory standards . Embrace GitOps today to secure your infrastructure, streamline compliance, and drive innovation .	Luis Alberto Vinay	2024-10-31	https://schub.cloud/web/image/249695-427ea28d/Blog%20SEP_AI%20Risk%20Repository-Post-Linkedin.png	https://schub.cloud/blog/blog-1/the-ai-risk-repository-10
98	Stop wasting money on the Cloud. 	 Developed by MIT Initiative on the Digital Economy, the AI Risk Repository boasts a continuously updated database exceeding 700 distinct AI risks . Database is meticulously maintained by a dedicated community of experts actively identifying and cataloging potential threats . Each risk entry is meticulously linked to relevant source information, including the original research paper title and author details . Database provides supporting evidence through quotes and page references from the source material .	Luis Alberto Vinay	2024-10-31	https://schub.cloud/web/image/249679-24df9876/Blog%20SEP_Cloud-Miniatura-blog.png	https://schub.cloud/blog/blog-1/stop-wasting-money-on-the-cloud-9
99	The European Union's AI Act Summary 	 In this Argentina Texas Chamber of Commerce (ATCC) webinar, Luis Vinay shares his almost ten years of experience transforming business objectives into next-generation cloud solutions . Get real-world professional techniques for effectively managing and optimizing your cloud expenses, ensuring that your cloud investment delivers maximum value .	Gastón Raúl Valdés	2024-10-31	https://schub.cloud/web/image/245392-cd0df9cc/The%20European%20Union%27s%20AI%20Act%20Summary%20%20-%20%20RRSS-80.jpg	https://schub.cloud/blog/compliance-5/the-european-union-s-ai-act-summary-8
100	Fully Declarative Cloud Infrastructure with ArgoCD	 The European Union's AI Act, a proposed regulation, outlines specific criteria for AI systems that determine whether they fall under its scope, including those related to fine-tuning or training AI models . Companies and AI professionals should stay informed and prepare for potential compliance requirements as the regulation evolves . The AI Act will be enforced in full in August 2027, but still local implementation on the different countries at the EU is under discussion .	João Filipe Moura	2024-10-31	http://schub.cloud/web/image/2003-dab88446/IMG%20BLOG.png	https://schub.cloud/blog/blog-1/fully-declarative-cloud-infrastructure-with-argocd-7
101	Imperative vs Declarative Automation | Part 2: Imperative Automation	 ArgoCD is the first tool that enables a fully declarative Continuous Delivery on Kubernetes . We've seen it often being used in a way that introduces (at least) one imperative step during the Application setup . The first two approaches have one fatal flaw: store the Application records on the infrastructure that can be destroyed . Using Application Manifests can be made to work declaratively, but it brings many code replication and maintainability complexities that need to be more worth it existing a fourth and correct approach . With this approach, the platform team can manage a single or a handful of files and scale the number of Applications effortlessly .	Luis Alberto Vinay	2024-10-31	http://schub.cloud/web/image/19728-06de83b4/Blog-images_2-part2.png	https://schub.cloud/blog/blog-1/imperative-vs-declarative-automation-discussion-part-2-imperative-automation-6
102	Imperative vs Declarative Automation | Part 1: Introduction Automation	 Imperative Automation is based on simple, flexible tools but that are complex to use . Complexity grows exponentially, since any intelligence (i.e: error handling, retries) must be implemented by the person working on the automation code; and as we all know, sometimes that kind of code is write-only . It has its applications where it's the perfect technical solution, but nowadays those cases are very specific ones .	Luis Alberto Vinay	2024-10-31	http://schub.cloud/web/image/19729-aa53df5b/Blog-images_1-part1.png	https://schub.cloud/blog/blog-1/imperative-vs-declarative-automation-discussion-part-1-introduction-3
103	Cybersecurity Awareness Month 2022	 Our current Cloud landscape would not be feasible if it weren't for automation; infrastructure that scales automatically based on the resource requirements would be virtually impossible otherwise . But not all automation is born equal; there are two antagonistic approaches to automation . One is Imperative Infrastructure Automation (simply Imperative Automation from now on) The other approach is Declarative infrastructure Automation . In the following sections and blog article, we will discuss the use cases and some limitations of both technologies to give a better idea of when each automation approach might be advisable over the other .	Luis Alberto Vinay	2024-10-31	http://schub.cloud/web/image/2006-20259270/Blog-images_agosto_1.png	https://schub.cloud/blog/blog-1/cybersecurity-awareness-month-2022-2
104	Schub's 2022 internship program	 Since 2004, the President of the United States and Congress have declared October Cybersecurity Awareness Month . The Cybersecurity and Infrastructure Security Agency (CISA) and the National Cybersecurity Alliance (NCA) lead a collaborative effort between government and industry to educate in cybersecurity nationally and internationally . October will focus on the “people” part of cybersecurity, providing information and resources to help educate CISA partners and the public, and ensure all individuals and organizations make smart decisions .	Luis Alberto Vinay	2024-10-31	http://schub.cloud/web/image/1607-aaec9119/Foto%2Bpasantes%2B2022%2Bfor%2Blinkedin.jpeg	https://schub.cloud/blog/blog-1/schub-s-2022-internship-program-1
105	Schub's 2022 internship program	 In the past few weeks, we kicked off the first iteration of our internship program . The main goal is to give high school young women and men their first contact with the professional world . Schub is in Argentina, a country with a long history of quality public education . Despite budget challenges, public technical schools have provided great talent for local and international companies .	Luis Alberto Vinay	2024-10-31	http://schub.cloud/web/image/1607-aaec9119/Foto%2Bpasantes%2B2022%2Bfor%2Blinkedin.jpeg	https://schub.cloud/blog/blog-1/schub-s-2022-internship-program-1
106	North Korean Group Collaborates with Play Ransomware in Significant Cyber Attack	\N	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgY8LAsTysxOLp2_jKtDmZCnUZ4CCOpLkKu9CN1kD1nohCJhc9gDXU-hXOwCXP6gFvC-LUjC_t2PtSSGvAtJKA1fes8gsCzuR1Xs5uN6mrrIMPWx1riBnXSwESbcQEz5chjyrdJURZy2ckBFmDDhzkusdE3WnA1VOlMm_P1dKHSNzCnNVlSKxkRKdO2tKLU/s728-rw-e365/paynow.png	https://thehackernews.com/2024/10/north-korean-group-collaborates-with.html
107	Opera Browser Fixes Big Security Hole That Could Have Exposed Your Information	 Threat actors linked to North Korea have been implicated in a recent incident that deployed a known ransomware family called Play . The activity, observed between May and September 2024, has been attributed to a threat actor tracked as Jumpy Pisces, which is also known as Andariel, APT45, DarkSeoul, Nickel Hyatt, Onyx Sleet, Operation Troy, Silent Chollima, and Stonefly . The development is a sign that North Korean threat actors could stage more widespread ransomware attacks .	@TheHackersNews	2024-10-31	https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgRyMsVeMT7VtRd_QXkviMkb25Nd_aEb6Sw7aJ9whsaekrv8OhxD5u1HDlUW4MqfEDS6NijHlJGrVQL0M6g0zqXzR66MS7oqrKGIbzx4ahexyKFjzFyo93IZo44_Jt6MpJRzwW0dX21ufgAWSDsZMcVqQidGbjRE8GB4y_Xx-JFtIHlaL6iyYpAB7dK3wT9/s728-rw-e365/attack.png	https://thehackernews.com/2024/10/opera-browser-fixes-big-security-hole.html
112	GitOps as a Security & Compliance Enabler	 In the rapidly evolving landscape of technology, maintaining robust security and compliance frameworks is a top priority for any organization . By utilizing GitOps methodologies, companies can significantly enhance their security posture and ensure compliance with regulatory standards . Embrace GitOps today to secure your infrastructure, streamline compliance, and drive innovation .	Ben Rodríguez	2024-10-31	https://schub.cloud/web/image/249753-e0096082/Blog-JULIO_Miniatura-blog.png	https://schub.cloud/blog/blog-1/gitops-as-a-security-compliance-enabler-43
\.


--
-- Data for Name: newsletters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newsletters (id, issue, id_art1, id_art2, id_art3, id_art4, id_art5, staten, creator, date) FROM stdin;
39	Newsletter	\N	98	99	\N	91	1	1	2024-10-31
41	NEWS: SCHUB	99	\N	91	100	92	1	1	2024-10-31
\.


--
-- Data for Name: states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.states (id, namestate, public) FROM stdin;
1	Publicado	t
2	NoPublicado	f
3	Desarrollo	f
4	EN ESPERA	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, usuario, email, contrasena, fecha, idrol) FROM stdin;
1	Laureano Furno	laureano@gmail.com	contra	2024-09-29	2
2	Laureano	lau@gmail.com	$2a$06$g46J/tYSrcj46KjgvQH9reh4IT/Mi15cWKjBqOxu6XnaZyzwfjjjO	2024-09-29	2
3	Gustavo	laureanofurno@gmail.com	$2a$06$r.6z.3TRcxyHbO.BAUDB6eNB7JzQAKYtCe4an0Fe32vyOfvRqvW.y	2024-10-01	2
4	Martin	Martin@gmail.com	$2a$06$JFzb2gq5JNchahPFahCun.jStCFyTHTn7BGI0o/XDed/Qkq6n72ii	2024-10-01	2
5	Bruno	Bruno@gmail.com	$2a$06$/G14o/kp5BEoitkCu3A7ueeE0ErAes4g8x1e2ohjebGhnkLUm0QJS	2024-10-01	2
6	Milena	Milena@gmail.com	$2a$06$U98wK9bymUjEhqh9S216yubb9nHmKZnLYO2s97Z5EYt7ibdfWzhE6	2024-10-01	2
\.


--
-- Name: article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.article_id_seq', 113, true);


--
-- Name: newsletters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.newsletters_id_seq', 41, true);


--
-- Name: states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.states_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: article article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.article
    ADD CONSTRAINT article_pkey PRIMARY KEY (id);


--
-- Name: newsletters newsletters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_pkey PRIMARY KEY (id);


--
-- Name: states states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT states_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: newsletters newsletters_id_art1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_id_art1_fkey FOREIGN KEY (id_art1) REFERENCES public.article(id);


--
-- Name: newsletters newsletters_id_art2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_id_art2_fkey FOREIGN KEY (id_art2) REFERENCES public.article(id);


--
-- Name: newsletters newsletters_id_art3_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_id_art3_fkey FOREIGN KEY (id_art3) REFERENCES public.article(id);


--
-- Name: newsletters newsletters_id_art4_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_id_art4_fkey FOREIGN KEY (id_art4) REFERENCES public.article(id);


--
-- Name: newsletters newsletters_id_art5_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_id_art5_fkey FOREIGN KEY (id_art5) REFERENCES public.article(id);


--
-- Name: newsletters newsletters_staten_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsletters
    ADD CONSTRAINT newsletters_staten_fkey FOREIGN KEY (staten) REFERENCES public.states(id);


--
-- PostgreSQL database dump complete
--

