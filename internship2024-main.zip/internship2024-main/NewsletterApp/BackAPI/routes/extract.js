import {extract} from '@extractus/article-extractor';
import {Router} from "express";
import 'dotenv/config';

const router  = Router();

const extractTheArticle = async (req, res) => {
    const { url } = req.body;
    var proxyURL = `${process.env.PROXY_URL}?url=${encodeURIComponent(url)}`;
    try {
        const article = await extract(proxyURL);
    } catch (err) {
        console.error(err);
    }
    
    const article = await extract(proxyURL);
    //console.log(article);
    res.json(article);
}

router.post('/extractTheArticle', extractTheArticle);
export default router;
