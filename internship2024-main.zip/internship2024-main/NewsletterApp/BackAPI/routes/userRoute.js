import { Router } from "express";
import { UserController } from "../controllers/userController.js";
import { articles } from "../controllers/articleController.js";
import { verifyToken } from "../middlewares/jwtMiddleware.js";
import { NewsletterController } from "../controllers/newsletterController.js";

const router = Router();

// register and login dont need jwt auth
router.post('/register', UserController.register);
router.post('/login', UserController.login);
router.post('/compare2StepCode', verifyToken,UserController.compare2StepCode);
router.get('/profile', verifyToken, UserController.profile);

router.post('/addArticle',verifyToken, articles.addArticle)
router.get('/extractArticles',verifyToken, articles.extractArticles);
router.get('/addNewsletterMaker',verifyToken, articles.addNewsletterMaker);
router.delete('/deleteArticle',verifyToken, articles.deleteArticle);
router.post('/almacenarNewsletter',verifyToken, NewsletterController.registerNewsletter);
router.get('/searchNewsletters',verifyToken, NewsletterController.extractNewssletters);
router.get('/searchArticlesByID',verifyToken, NewsletterController.searchArticlesByID);
router.delete('/deleteNewsletter',verifyToken, NewsletterController.deleteNewsletter);

router.get('/editNewsletter',verifyToken, NewsletterController.editNewsletter);
router.post('/editAlterTable',verifyToken, NewsletterController.editAlterTable);
router.post('/changeStateNewsletter',verifyToken, NewsletterController.changeState);
router.get('/searchAuthorID',verifyToken, NewsletterController.searchAuthorID);

export default router;
