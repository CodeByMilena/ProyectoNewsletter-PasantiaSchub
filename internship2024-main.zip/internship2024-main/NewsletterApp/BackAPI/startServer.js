import 'dotenv/config';
import express from 'express';
import cors from 'cors'; // Changed here
import publicRouter from './routes/publicRoute.js';
import userRouter from './routes/userRoute.js';
import extraer from './routes/extract.js';
import fetch from 'node-fetch';
import bodyParser from 'body-parser';
import session from 'express-session';
import { sequelize } from './database/configDatabase.js';
//import './models/initModels.js'
const app = express();

//configuring server parameters
const corsOptions = {
    origin: '*', //***I removed static addresses from here maybe we can use an environment variable for this***
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization'],
};

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(bodyParser.json({ limit: '100mb' })); // Size limit to pass the base64, it is very large and trigers errors, be careful.
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }));

//Declare the API end points
app.use('/', publicRouter);
app.use('/extract', extraer);
app.use('/api/v1/users', userRouter);

//define port

const PORT = process.env.PORT;

console.log(process.env.EMAIL_USER)

app.get('/proxy', async (req, res) => {
    const url = req.query.url;
    if (!url) {
        return res.status(400).send('No URL provided');
    }

    try {
        const response = await fetch(url);
        const data = await response.text();
        res.send(data);
    } catch (error) {
        res.status(500).send('Error fetching the URL');
    }
});

//start server and send message to console
app.listen(PORT, () => {
    console.log(`Proxy server running at http://localhost:${PORT}`);

});
