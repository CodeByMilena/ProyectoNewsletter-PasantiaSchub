import { Sequelize } from 'sequelize';
import 'dotenv/config';
import { PostgresDialect } from '@sequelize/postgres';

export const sequelize = new Sequelize(process.env.DATABASE_BD, process.env.DATABASE_USER , process.env.DATABASE_PASSWORD,
  {
  host: process.env.DATABASE_HOST,
  dialect: 'postgres',
  port: process.env.DATABASE_PORT,
});

// Probar la conexión
sequelize.authenticate()
  .then(() => {
    console.log('Successful conection to the PostgreSQL');
  })
  .catch((err) => {
    console.error('Error in the connected to the PostgreSQL', err);
  });


// Sincronizar modelos con la base de datos
sequelize.sync()
  .then(() => {
    console.log('Modules Postgres is connected');
  })
  .catch((err) => {
    console.error('Error in the synchronize models:', err);
  });
