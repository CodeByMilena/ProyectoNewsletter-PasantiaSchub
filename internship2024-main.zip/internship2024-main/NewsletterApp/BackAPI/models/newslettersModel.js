import { DataTypes } from 'sequelize';
import {sequelize} from '../database/configDatabase.js';

const newsletters = sequelize.define('newsletters',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    issue: {
        type: DataTypes.STRING(40),
        allowNull: false,
        validate:{
            notEmpty: {
                msg: 'Please, select an article for the white space in the first section of the newsletter.'
            }
        }
    },
    id_art1: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'Please, select an article for the white space in the first section of the newsletter.'
            }
        }
    },
    id_art2: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'Please, select an article for the white space in the second section of the newsletter.'
            }
        }
    },
    id_art3: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'Please, select an article for the white space in the third section of the newsletter.'
            }
        }
    },
    id_art4: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'Please, select an article for the white space in the fourth section of the newsletter.'
            }
        }
    },
    id_art5: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'Please, select an article for the white space in the fifth section of the newsletter.'
            }
        }
    },
    staten: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    creator: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    date: {
        type: DataTypes.DATE,
        allowNull: false
    },

},{
    tableName: 'newsletters',
    timestamps: false
});
export default newsletters;
