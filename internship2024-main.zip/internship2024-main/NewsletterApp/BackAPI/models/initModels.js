import { article } from './SQL_Articles';
import { newsletters } from './SQL_Newsletters';
import { States } from './SQL_States';
import { users } from './SQL_Users';

States.hasMany(newsletters, { foreignKey: 'staten' });
newsletters.belongsTo(States, { foreignKey: 'staten' });

users.hasMany(newsletters, { foreignKey: 'creator' });
newsletters.belongsTo(users, { foreignKey: 'creator' });

article.hasOne(newsletters, { foreignKey: 'id_art1' });
article.hasOne(newsletters, { foreignKey: 'id_art2' });
article.hasOne(newsletters, { foreignKey: 'id_art3' });
article.hasOne(newsletters, { foreignKey: 'id_art4' });
article.hasOne(newsletters, { foreignKey: 'id_art5' });

export {article, newsletters, States, users}
