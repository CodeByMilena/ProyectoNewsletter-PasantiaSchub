import jwt from 'jsonwebtoken';

const decodeJWT =  (creator) => {
    const decoded = jwt.decode(creator);
    console.log(decoded)
    return decoded;  
};

export const decodeAR = {
    decodeJWT
}
