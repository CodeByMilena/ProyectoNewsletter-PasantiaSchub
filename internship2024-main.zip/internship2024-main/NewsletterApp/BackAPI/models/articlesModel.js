import { DataTypes } from 'sequelize';
import {sequelize} from '../database/configDatabase.js';

const article = sequelize.define('article',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING(150),
        allowNull: false,
    },
    summary: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate:{
            notEmpty: {
                msg: 'The summary must not be empty'
            },
            notNull: {
                msg: 'The summary must not be null'
            }
        }
    },
    author: {
        type: DataTypes.STRING(150),
        allowNull: false,
        validate:{
            notNull: {
                msg: 'The author must not be null'
            }
        }
    },
    creationdate:{
        type: DataTypes.DATE,
        allowNull: false
    },
    imagen: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    paglink:{
        type: DataTypes.TEXT,
        allowNull: false,
        validate:{
            notNull: {
                msg: 'The link of the original article must not be null'
            }
        }
    }
},{
    tableName: 'article',
    timestamps: false
});

export default article;
