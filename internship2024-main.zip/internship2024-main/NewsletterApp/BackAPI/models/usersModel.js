import { DataTypes } from 'sequelize';
import {sequelize} from '../database/configDatabase.js';

const users = sequelize.define('users',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    username: {
        type: DataTypes.STRING(50),
        allowNull: false,
        validate:{
            notEmpty: {
                msg: 'The username must not be empty'
            }
        }
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        validate:{
            notEmpty: {
                msg: 'The email must not be empty'
            }
        }
    },
    passw: {
        type: DataTypes.STRING(255),
        allowNull: false,
        validate:{
            notEmpty: {
                msg: 'The password must not be empty'
            }
        }
    },
    dated: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    idrol:{
        type: DataTypes.INTEGER,
        allowNull: false
    }
},{
    tableName: 'users',
    timestamps: false
});
export default users;
