import { DataTypes } from 'sequelize';
import {sequelize} from '../database/SQL_config.js';

const States = sequelize.define('states',{
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    namestate: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    public: {
        type: DataTypes.BOOLEAN,
        allowNull: false
    }
},{
    tableName: 'states',
    timestamps: false
});
export default States;
