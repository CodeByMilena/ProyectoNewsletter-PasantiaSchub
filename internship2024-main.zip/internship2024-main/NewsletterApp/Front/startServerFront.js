const express = require('express');
const path = require('path');
const cors = require('cors');
//declare app server and Port
const app = express();
const PORT = 5000; //***We should change this to environment variable***

require('dotenv').config();

const corsOptions = {
    origin: '*', //***I removed static addresses from here maybe we can use an environment variable for this***
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization'],
};

app.use(cors(corsOptions));

//declare the phisical paths for routes
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'register'))); 
app.use(express.static(path.join(__dirname, 'articulos')));
app.use(express.static(path.join(__dirname, 'auten')));
app.use(express.static(path.join(__dirname, 'extraer')));
app.use(express.static(path.join(__dirname, 'maquetado')));
app.use(express.static(path.join(__dirname, 'NewsletterLibrary')));

//declare default file to route 'login
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
//declare default file to route 'register'
app.get('/register/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register', 'register.html'));
});
//declare default file to route 'articulos'
app.get('/articulos/', (req, res) => {
    res.sendFile(path.join(__dirname, 'articulos', 'articulos.html'));
});
//declare default file to route 'auten'
app.get('/auten/', (req, res) => {
    res.sendFile(path.join(__dirname, 'auten.html', 'auten.html'));
});
//declare default file to route 'extraer'
app.get('/extraer/', (req, res) => {
    res.sendFile(path.join(__dirname, 'extraer', 'extraer.html'));
});
//declare default file to route 'maquetado'
app.get('/maquetado/', (req, res) => {
    res.sendFile(path.join(__dirname, 'maquetado', 'maquetado.html'));
});
//declare default file to route 'NewsletterLibrary' ***by the way bad idea to use CamelCase just for this one***
app.get('/NewsletterLibrary/', (req, res) => {
    res.sendFile(path.join(__dirname, 'NewsletterLibrary', 'NewsLetter.html'));
});
//declare default file to route 'prueba' in this case prueba is redirected to articulos/prueba.html
app.get('/articulos/', (req, res) => {
    res.sendFile(path.join(__dirname, 'prueba', 'prueba.html'));
});
//declare default file to route 'prueba' in this case prueba is redirected to articulos/prueba.html
app.get('/articulos/', (req, res) => {
    res.sendFile(path.join(__dirname, 'articulos', 'articulos.html'));
});

//start server and send message to console
app.listen(PORT, () => {
    console.log(`Servidor levantado en http://localhost:${PORT}`);
});
