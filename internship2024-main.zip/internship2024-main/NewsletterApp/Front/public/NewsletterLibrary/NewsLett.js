const AXIOSBACK = 'https://newsletter-api.schub.cloud/api/v1/users/';

//const AXIOSBACK = 'http://localhost:3000/api/v1/users/' //guardo para prueba local

let contenedor = document.getElementById('caja');

axios.get(`${AXIOSBACK}searchNewsletters`) //*** HARDCODED URL!!! we must fix this
    .then(({ data }) => {
        console.log(data.msg);
        for (let i = 0; i < data.msg.length; i++) {
            const id = data.msg[i].id;
            const issue = data.msg[i].issue;
            const id1 = data.msg[i].id_art1;
            const id2 = data.msg[i].id_art2;
            const id3 = data.msg[i].id_art3;
            const id4 = data.msg[i].id_art4;
            const id5 = data.msg[i].id_art5;
            const state = data.msg[i].staten;
            const creator = data.msg[i].creator;
            const fecha = data.msg[i].date;
            if (data.msg.length >= 20) {
                console.log(data.msg[i])

            } else {
                cardNewsletter(id, issue, id1, id2, id3, id4, id5, state, creator, fecha)
            }
        }
    })
    .catch(error => {
        console.error('Error al obtener los artículos:', error);
    });

function cardNewsletter(id, issue, id1, id2, id3, id4, id5, state, creator, date) {
    let contenedor = document.getElementById('show');
    const fechaString = new Date(date)

    const op = { day: 'numeric', month: 'long', year: 'numeric' };
    const fechaForm = fechaString.toLocaleDateString('es-ES', op)
    let listaID = [id1, id2, id3, id4, id5];
    let listaPromesas = [];
    // Usamos un bucle `for` para crear y agregar cada promesa a `listaPromesas`
    for (let i = 0; i < listaID.length; i++) {
        listaPromesas.push(
            axios.get(`${AXIOSBACK}searchArticlesByID?id=${listaID[i]}`) //*** HARDCODED URL!!! we must fix this
                .then(({ data }) => 
                    data.msg[0].title,

                    axios.get(`${AXIOSBACK}searchAuthorID?id=${creator}`) //*** HARDCODED URL!!! we must fix this
                    .then(({ data }) => data.msg[0].usuario)
                    .catch(error => {
                        console.error('Error al obtener el artículo:', error);
                        return null; // En caso de error, devolver null
            })
            )
                .catch(error => {
                    console.error('Error al obtener el artículo:', error);
                    return null; // En caso de error, devolver null
                }),
        );
        
    }

    listaPromesas.push(
         axios.get(`${AXIOSBACK}searchAuthorID?id=${creator}`) 
                .then(({ data }) => data.msg[0].usuario)
                .catch(error => {
                    console.error('Error al obtener el artículo:', error);
                    return null; 
            })
    )
    // Espera a que todas las promesas se resuelvan
    Promise.all(listaPromesas).then(listaTitulos => {
        console.log(listaTitulos)
        if (state !== 1) {
            contenedor.innerHTML += `
            <div class="card" id='${id}'>
                <div style="color:red;" class="date">${fechaForm}</div>
                <div class="section">
                    <div class="title">Articulos</div>
                    <ul class="articles">
                        <li style="color:red;" > -> ${listaTitulos[0] || ''}</li>
                        <li style="color:red;"> -> ${listaTitulos[1] || ''}</li>
                        <li style="color:red;"> -> ${listaTitulos[2] || ''}</li>
                        <li style="color:red;"> -> ${listaTitulos[3] || ''}</li>
                        <li style="color:red;"> -> ${listaTitulos[4] || ''}</li>
                    </ul>
                </div>
                <div class="section">
                    <div class="title">${listaTitulos[5]}</div>
                </div>
                <div style="color:red;" class="status">Estado: ${state} <button style="color:red; border-color:red;" class="botonSel" onclick="changeState(${id})">Publicar</button></div>
                <button style="color:red; border-color:red;"  class="botonSel" onclick="toggleCardSelection(${id})">Seleccionar</button>
            </div>
        `;
        } else {
            contenedor.innerHTML += `
            <div class="card" id='${id}'>
                <div class="date">${fechaForm}</div>
                <div class="section">
                    <div class="title">Articulos</div>
                    <ul class="articles">
                        <li> -> ${listaTitulos[0] || ''}</li>
                        <li> -> ${listaTitulos[1] || ''}</li>
                        <li> -> ${listaTitulos[2] || ''}</li>
                        <li> -> ${listaTitulos[3] || ''}</li>
                        <li> -> ${listaTitulos[4] || ''}</li>
                    </ul>
                </div>
                <div class="section">
                    <div class="title">${listaTitulos[5]}</div>
                </div>
                <div class="status">Estado: ${state} 
                <button class="botonSel" onclick="toggleCardSelection(${id})">Seleccionar</button>
            </div>
        `;
        }
    });
}
function changeState(id) {
    axios.post(`${AXIOSBACK}changeStateNewsletter?id=${id}`)
        .then(({ data }) => {
            console.log('Estado actualizado:', data);
            location.reload()
        })
        .catch(error => {
            console.error('Error al obtener los artículos:', error);
        });
}
function borrarNewsletter() {
    let idP = parseInt(localStorage.getItem('numeroNewsl'));
    // console.log('Borrado:' + idP)
    // for(let i = 0; i < idP.length; i++){
    //console.log("conso: " +  idP[i])
    axios.post(`${AXIOSBACK}deleteNewsletter?id=${idP}`) //*** HARDCODED URL!!! we must fix this
        .then(({ data }) => {
            location.reload();
        }
        )
        .catch(error => {
            console.error('Error al obtener los artículos:', error);
        });
}

// }
function EditNewsletter() {
    let listaArticulosNewsEdit = []
    let idP = parseInt(localStorage.getItem('numeroNewsl'));
    axios.get(`${AXIOSBACK}editNewsletter?id=${idP}`)
        .then(({ data }) => {
            console.log(data.msg)
            listaArticulosNewsEdit.push(data.msg[0])
            listaArticulosNewsEdit.push(data.msg[1])
            listaArticulosNewsEdit.push(data.msg[2])
            listaArticulosNewsEdit.push(data.msg[3])
            listaArticulosNewsEdit.push(data.msg[4])
            localStorage.setItem('listaCardsNumsEdit', JSON.stringify(listaArticulosNewsEdit))
            location.href = "../maquetado/maquetado.html"
        }
        )
        .catch(error => {
            console.error('Error al obtener los artículos:', error);
        });
}
window.borrarNewsletter = () => borrarNewsletter();
window.EditNewsletter = () => EditNewsletter();
window.changeState = (id) => changeState(id); //cambia el estado para que acepte el parametro id

