const AXIOSBACK = 'https://newsletter-api.schub.cloud/api/v1/users/';

//const AXIOSBACK = 'http://localhost:3000/api/v1/users' //guardo para prueba local
window.onload = function() {
    iniciarArticulosEditar();
    Swal.fire({
        title: 'How to assemble newsletters!',
        icon: 'info',
        html: `
          <div style="display: flex; flex-direction: column; align-items: center;">
            <p style='margin-top:0px; margin-bottom:10px;'>This view will allow you to assemble a newsletter, for it you will have to click on an article, then click in what part of the template it should appear.</p>
            <video width="400" height="250" style='margin-top:0px;' controls>
              <source src="./example.mp4" type="video/mp4" style='margin-top:0px;'>
              Your browser does not support the video tag.
            </video>
          </div>
        `,
        confirmButtonText: 'OK'
    });
      
      
};
let div = document.getElementById('cajaArticulos');
let divsNoticias = div.getElementsByTagName('label');
const secciones = document.querySelectorAll('.test');
let seccionChosen = null;
let articuloChosen=null;
let verificar1 = true;
let verificar2 = true;
let verificar3 = true;
let verificar4 = true;
let verificar5 =true;
const listaArticulosUsados = [];
let articulosUsado = "";
let test = localStorage.getItem('ListaArticulosExtraidos');
let testEdit = JSON.parse(localStorage.getItem('listaCardsNumsEdit'));
let tes = JSON.parse(test);

let titulo = document.getElementById('titulo');
let cuerpo = document.getElementById('cuerpo');

// Agregar el event listener al div hijo

//lista de articulos
function iniciarArticulosEditar(){
    if (localStorage.getItem('listaCardsNumsEdit') !== null) {
        artEdit1()
        artEdit2()
        artEdit3()
        artEdit4()
        artEdit5()
    }
}

function artEdit1() {
    if (testEdit[0].length !== 0) {
        document.getElementById('p2_Sec').innerHTML = ""
        let t = testEdit[0][0].title;
        let half = Math.floor(t.length / 2);
        let titulo1 = t.slice(0, half);
        let titulo2 = t.slice(half, t.length);
        console.log(testEdit[0][0].id)


        document.getElementById('p2_Sec').innerHTML = `
         <div style="margin-left: 5%;">
                            <h2 class="subtitulo as">${titulo1}</h2>
                            <h3 style="color: #778770;" class="subtitulo as">${titulo2}</h3>
                        </div>
                        <p class="sub-texto as">
                           ${testEdit[0][0].summary}
                        </p>
                        <img src="${testEdit[0][0].imagen}" class="imagenDS as"  alt="1er imagen" id="img1">
    `
    listaArticulosUsados[0] = testEdit[0][0].id

    }
}
function artEdit2() {
    if (testEdit[1].length !== 0) {
        let t = testEdit[1][0].title;
        let half = Math.floor(t.length / 2);
        let titulo1 = t.slice(0, half);
        let titulo2 = t.slice(half, t.length);
        console.log(testEdit)
        document.getElementById('p3_Sec').innerHTML = `
                        <div style="margin-left: 5%;">
                           <h2 style="color: white;" class="subtitulo as">${titulo1}</h2>
                           <h3 style="color: #000000;" class="subtitulo as">${titulo2}</h3>
                       </div>
                       <p class="sub-texto as">
                          ${testEdit[1][0].summary}
                       </p>
                       <img src="${testEdit[1][0].imagen}" class="imagenDS as"  alt="1er imagen" id="img2">
                        <img src="placeholder.jpg" class="imagenDS as" alt="3er imagen" id="img3">
                        
    
    `
    listaArticulosUsados[1] = testEdit[1][0].id

    }

}
function artEdit3() {
    if (testEdit[2].length !== 0) {
        let t = testEdit[2][0].title;
        let half = Math.floor(t.length / 2);
        let titulo1 = t.slice(0, half);
        let titulo2 = t.slice(half, t.length);
        document.getElementById('p4_Sec').innerHTML = `
        <div style="margin-left: 5%;">
                                <h2 style="color: rgb(0, 0, 0);" class="subtitulo as">${titulo1}</h2>
                                <h3 style="color: #778770;" class="subtitulo as">${titulo2}</h3>
                            </div>
                            <p class="sub-texto as">
                                 ${testEdit[2][0].summary}
                            </p>
                            <img src="${testEdit[2][0].imagen}" class="imagenDS as" alt="1er imagen" id="img1"></img>
                            <form action="">
                                <button type="button" class="button boton1">IR LINK</button>
                                <button type="button" class="button boton2">BOTON</button>
                            </form>
    `
    listaArticulosUsados[2] = testEdit[2][0].id

    }
}
function artEdit4() {
    if (testEdit[4].length !== 0) {
        let t = testEdit[4][0].title;
        let half = Math.floor(t.length / 2);
        let titulo1 = t.slice(0, half);
        let titulo2 = t.slice(half, t.length);
        document.getElementById('p5_Sec').innerHTML = `
                            <div style="margin-left: 5%;">
                                <h2 style="color: white;" class="subtitulo as">${titulo1}</h2>
                                <h3 style="color: white;" class="subtitulo as">${titulo2}</h3>
                            </div>
                            <p style="color: white;" class="sub-texto as">
                                ${testEdit[4][0].summary}
                            </p>
                            <img src="${testEdit[4][0].imagen}" class="imagenDS as" alt="1er imagen" id="img1"></img>
                            <button type="button" class="boton3">BOTON</button>
    
    `
    console.log(testEdit[4][0].id)
    listaArticulosUsados[4] = testEdit[4][0].id
    }

}
function artEdit5() {
    if (testEdit[3].length !== 0) {
        let t = testEdit[3][0].title;
        let half = Math.floor(t.length / 2);
        let titulo1 = t.slice(0, half);
        let titulo2 = t.slice(half, t.length);
        document.getElementById('p6_Sec').innerHTML = `
                        <section id="p6_Sec" class="test">
                            <div style="margin-left: 5%;">
                                <h2 style="color: white;" class="subtitulo as">${titulo1}</h2>
                                <h3 style="color: #000000;" class="subtitulo as">${titulo2}</h3>
                            </div>
                                <p style="color: white;" class="sub-texto as">
                                ${testEdit[3][0].summary}
                                </p>
                            <img src="${testEdit[3][0].imagen}" class="imagenDS as" alt="2da imagen" id="img2">
                            <img src="placeholder.jpg" class="imagenDS as" alt="3er imagen" id="img3">

    `
    listaArticulosUsados[3] = testEdit[3][0].id
}

}

generarArticulosBox();
function generarArticulosBox() {
    for (let i = 0; i < tes.length; i++) {
        div.innerHTML += "<label for=" + 'noticia_' + i + ">" +
            "<section class='test2'>" +
            "<input type='checkbox' name='' id=" + 'noticia_' + i + " class='inputC'>" +
            "<h3 id='idArts'>" + tes[i].id + "</h3>" +
            "<h4 id='titulo'>" + tes[i].title + "</h4>" +
            "<p id='cuerpo'>" + tes[i].summary + "</p>" +
            "<img class='imagenSD' id='imagenSD' src=" + tes[i].imagen + ">" +
            "<p id='author'>" + 'Author:' + tes[i].author + "</p>" +
            "<a id='artOriginal' href=" + tes[i].paglink + ">Visitar articulo original</a>" +
            "</section>" +
            "</label>";
    }
    if (localStorage.getItem('listaCardsNumsEdit') !== null) {

        for (let i = 0; i < testEdit.length; i++) {
            for (let j = 0; j < testEdit[i].length; j++) {
                console.log(testEdit[i][j])
                div.innerHTML += "<label for=" + 'noticia_' + j + ">" +
                    "<section class='test2'>" +
                    "<input type='checkbox' name='' id=" + 'noticia_' + j + " class='inputC'>" +
                    "<h3 id='idArts'>" + testEdit[i][j].id + "</h3>" +
                    "<h4 id='titulo'>" + testEdit[i][j].title + "</h4>" +
                    "<p id='cuerpo'>" + testEdit[i][j].summary + "</p>" +
                    "<img class='imagenSD' id='imagenSD' src=" + testEdit[i][j].imagen + ">" +
                    "<p id='author'>" + 'Author:' + testEdit[i][j].author + "</p>" +
                    "<a id='artOriginal' href=" + testEdit[i][j].paglink + ">Visitar articulo original</a>" +
                    "</section>" +
                    "</label>";
            }

        }
    }

}





// evento para las noticias
const nots = document.querySelectorAll("label"); // Selecciona todos los artículos creados
nots.forEach(noticia => {
    noticia.addEventListener('click', () => {
            articuloChosen=noticia;
            if (articuloChosen) { 
                articuloChosen.classList.remove('seleccionado');
                nots.forEach(item => {
                    item.style.border = '';
                });
            }
            articuloChosen.classList.add('seleccionado')
            if (articuloChosen.classList.contains('seleccionado')) {
                articuloChosen.style.border = '1px solid green';
                secciones.forEach(seccion => {
                    seccion.addEventListener('click', () => {
                        if (seccionChosen) { //verifico si ya clickee uno
                            seccionChosen.classList.remove('seleccionado');
                        }
                        
                        seccionChosen = seccion;
                        seccionChosen.classList.add('seleccionado');
                        const linkk="<div class='boton1'><a class='linkss' href=" + articuloChosen.querySelector('#artOriginal') + ">Visitar articulo original</a>";
                        const contenidos = seccionChosen.querySelectorAll('.as');
                        const titul = articuloChosen.querySelector('#titulo');
                        const cuerp = articuloChosen.querySelector('#cuerpo');
                        const imagen = articuloChosen.querySelector('#imagenSD');
                        const autor = articuloChosen.querySelector('#author');
                        const ArticleID = articuloChosen.querySelector('#idArts');
                        if (seccionChosen) {
                            const sectionId = seccionChosen.id; // obtener el id de la sección elegida
                            let t = titul.textContent;
                            let half = Math.floor(t.length / 2);
                            let titulo1 = t.slice(0, half);
                            let titulo2 = t.slice(half, t.length);
                            let cuer = cuerp.textContent;
                            let img = imagen.src;
                            contenidos.forEach(contenid => {
                                if (verificar1) {
                                    contenid.innerText = titulo1;
                                    verificar1 = null;
                                } else if (verificar2) {
                                    contenid.innerText = titulo2;
                                    verificar2 = null;
                                } else if (verificar3) {
                                    contenid.innerText = cuer;
                                    verificar3 = null;
                                } else if (verificar4) {
                                    contenid.src = img
                                    verificar4 = null;
                                }
                                else if (verificar5) {
                                    contenid.innerHTML=linkk;
                                    verificar5 = null;
                                }
                            });
                        //    console.log(seccionChosen)
                            articulosUsado = ArticleID.textContent;
            
                            if(sectionId == "p2_Sec"){
                                listaArticulosUsados[0] = articulosUsado
                            }
                            if(sectionId == "p3_Sec"){
                                listaArticulosUsados[1] = articulosUsado
                            }
                            if(sectionId == "p4_Sec"){
                                listaArticulosUsados[2] = articulosUsado
                            }
                            if(sectionId == "p6_Sec"){
                                listaArticulosUsados[3] = articulosUsado
                            }
                            if(sectionId == "p5_Sec"){
                                listaArticulosUsados[4] = articulosUsado
                            }
                            articuloChosen=null;
                            seccionChosen = null;
                            verificar1 = true;
                            verificar2 = true;
                            verificar3 = true;
                            verificar4 = true;
                            verificar5 = true;
                        } else {
                            alert("¡Primero clickea una sección!");
                        }
                    });
                });
            }
    });
});



async function subirNewsletter() {
    const issue = document.getElementById('asuntoInput').value;
    const id_art1 = listaArticulosUsados[0];
    const id_art2 = listaArticulosUsados[1];
    const id_art3 = listaArticulosUsados[2];
    const id_art4 = listaArticulosUsados[3];
    const id_art5 = listaArticulosUsados[4];
    const state = 2;
    const creator = localStorage.getItem('token');

    if(localStorage.getItem('listaCardsNumsEdit') !== null){
        let id = parseInt(localStorage.getItem('numeroNewsl'))
        try {
            const { data } = await axios.post(`${AXIOSBACK}/editAlterTable`, {id, id_art1, id_art2, id_art3, id_art4, id_art5 }); 
            console.log(data);
            //Al terminar, localtion.hred te redirecciona a la vista autenticador
            console.log(data);
            alert('Request completed successfully');
            Swal.fire({
                title: 'SUCCESS assembling newsletter!',
                text: 'Successfully assembled newsletter, you will be moved to the newsletter library.',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                console.log("Redirecting after Swal closure...");
                setTimeout(() => {
                    location.href = '../NewsletterLibrary/NewsLetter.html';
                    localStorage.removeItem('listaCardsNumsEdit'); // Limpiar el localStorage
                }, 5000); // Redirigir después de 5 segundos
            });

        } catch (error) {
            console.log(error)
            Swal.fire({
                title: 'ERROR assembling newsletter!',
                text: 'check if you have changed all template sections, and if you filled the issue at the beginning.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    }else{
        try {
            const { data } = await axios.post(`${AXIOSBACK}/almacenarNewsletter`, { issue, id_art1, id_art2, id_art3, id_art4, id_art5, state, creator }); //*** HARDCODED URL!!! we must fix this
            console.log(data);
            //Al terminar, localtion.hred te redirecciona a la vista libreria newsletter
            location.href = '../NewsletterLibrary/NewsLetter.html';
            localStorage.removeItem('listaCardsNumsEdit')
        } catch (error) {
            console.log(error)
            Swal.fire({
                title: 'ERROR assembling newsletter!',
                text: 'check if you have changed all template sections, and if you filled the issue at the beginning.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            
        }
    }
    

};
window.subirNewsletter = () => subirNewsletter();


