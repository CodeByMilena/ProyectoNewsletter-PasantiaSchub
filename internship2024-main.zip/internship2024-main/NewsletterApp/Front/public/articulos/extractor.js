
const AXIOSBACK = 'https://newsletter-api.schub.cloud/extract/';
const AXIOSBACKING = 'https://newsletter-api.schub.cloud/api/v1/users/'

//const AXIOSBACK = 'http://localhost:3000/extract/'
//const AXIOSBACKING = 'http://localhost:3000/api/v1/users/'
extraerArticulo();
var listaArticulosObj = [];
var Seleccionados = {
    titulo: "",
    imagen: "",
    author: "",
    texto: "",
    paglink:"",
};

async function extraerArticulo(){
    var parrafoExtraido = document.getElementById('muestra');
    var input = localStorage.getItem('link');
   
    let cajaArt = document.getElementById('extraido');
    
    
    //console.log(article);
    //const claves = Object.keys(article);
    
    let url = localStorage.getItem('link')
    try {
        const {data} = await axios.post(`${AXIOSBACK}extractTheArticle`, {url});//*** HARDCODED URL!!! we must fix this
        if(document.referrer != location){
            localStorage.removeItem('listaParrafos')
        }
        console.log(data)
    
        if(!localStorage.getItem('listaParrafos')){
            JSON.stringify(localStorage.setItem('listaParrafos', data.content));
            let parrafoE = cajaArt.innerHTML = '<div>' +  data.content + '</div>';
        }else{
            let converti = JSON.parse(localStorage.getItem('listaParrafos'))
            for(let i = 0; i < converti.length; i++){
                let parrafoE = cajaArt.innerHTML += '<p>' +  converti[i] + '</p>';
            }
        }
        var ext = parrafoExtraido.innerHTML = '<h1>' + data.title + '</h1>';
        parrafoExtraido.innerHTML += '<p>'+'Author: ' + data.author + '</p>';
        Seleccionados["titulo"] = data.title;
        Seleccionados["author"] = data.author;
        mostrarParrafos();
        mostrarImagenes(data.image);

    } catch (error) {
        console.log(error)
    }
} 

function mostrarImagenes(imgBack){
    let cajaArt = document.getElementById('extraido');
    const mImg = cajaArt.getElementsByTagName('img');
  //  console.log(mImg.item(1))
    let imagenesMuestra = document.getElementById('muestraImagen');
    imagenesMuestra.innerHTML = '';

    let listaImagenes =[];
    let urlsImg = new Set(); //guardar urls de imagenes ya agregadas

    for(let i = 0; i < mImg.length; i++){
        let imagen = mImg[i];
        let url = imagen.src; 

        if(!urlsImg.has(url)){
            urlsImg.add(url);
            let imagenClonada = mImg[i].cloneNode(true);
            imagenesMuestra.appendChild(imagenClonada);
            listaImagenes.push(imagenClonada);
          
        }
    }
    imagenesMuestra.innerHTML += '<img src="'+imgBack+'" alt="">';
    listaImagenes.push(imgBack);
    let arrayCopia = listaImagenes.slice();
    window.seleccionarImagen = () => seleccionarImagen(arrayCopia);
    seleccionarImagen(arrayCopia);
    
}


const listaVaciaSoloTxt = [];

function mostrarParrafos(){
    const parrafos = localStorage.getItem('parrafos')

    let cajaArt = document.getElementById('extraido');
    const paraExtraer = document.querySelectorAll('#extraido p');

    const parrafoExtraido = document.getElementById('muestra');
    
    parrafoExtraido.innerHTML += ''; 
    listaVaciaSoloTxt.length = 0;
    paraExtraer.forEach((p, index) => {
        const cont = p.textContent.trim();
        if(cont != ''){
            parrafoExtraido.innerHTML += `<p>${cont}</p>`;
            listaVaciaSoloTxt.push(cont);
        }
    });

    localStorage.setItem('listaParrafos',JSON.stringify(listaVaciaSoloTxt))
    console.log(listaVaciaSoloTxt)

  //Eliminar parrafos vacios:
  const parrafosVaciosEliminar = document.querySelectorAll('#muestra p:empty');
  parrafosVaciosEliminar.forEach(p => p.remove());
    
}


var imagenesG = [];

function seleccionarImagen(listaImagenes){
    //console.log(listaImagenes)
    var inputNUMB = document.getElementById('numeroImagen');
    var IMGSelecc = document.getElementById('IMGSelecc')
    var valor = inputNUMB.value.trim();
    let convertido = parseInt(valor, 10) - 1;
    let cc = listaImagenes[convertido];
    let pp = '<img id="imgSelExt" src="'+cc.src+'" alt="">';
    imagenesG.push(pp);
    console.log(cc)

    if (typeof cc === 'string' && !cc.includes('<img alt="')) {
        IMGSelecc.innerHTML += '<img id="imgSelExt" src="' + cc + '" alt="">';
        Seleccionados["imagen"] = cc;
    } else if (cc && cc.alt) {
        IMGSelecc.appendChild(cc);
        Seleccionados["imagen"] = cc.src;
    }
}

function parrafoParaMod(){
    const seccionMostrar = document.getElementById('textAreaIn');
    const textArea = document.getElementById('parrafoModificado');
    seccionMostrar.style.display = 'block';
    
    for(let i = 0; i < listaVaciaSoloTxt.length; i++){
        textArea.value += listaVaciaSoloTxt[i];
        textArea.value += "\n\n"
    }
}
function guardarModificacion(){
    
    const textArea = document.getElementById('parrafoModificado');

    localStorage.removeItem('listaParrafos');
    listaVaciaSoloTxt.length = 0;


    const lineaTextArea = textArea.value.split('\n')
    //filtro lineas vacias con trim
    const lineasFiltradas = lineaTextArea.filter(lineaTextArea => lineaTextArea.trim() !== '');

    lineasFiltradas.forEach(lineaTextArea => {
        listaVaciaSoloTxt.push(lineaTextArea)
    })

    localStorage.setItem('listaParrafos', JSON.stringify(listaVaciaSoloTxt));
    location.reload();
}
/*no funciona pero lo guardo
    for(let i = 0; i < imagenes.length; i++){
        listaImagenes[i] = imagenes[i];
    }    
    for(let g = 0; g < listaImagenes.length; g++){
        imagenesMuestra.innerHTML += '<img>' + listaImagenes[g] + '</img>';
    }

function irMaquetado(){
    localStorage.removeItem('listaParrafos');
    location.href = 'maquetado/maquetado.html'
}
*/
window.guardarDatos = () => guardarDatos();
window.parrafoParaMod = () => parrafoParaMod();
window.guardarModificacion = () => guardarModificacion();
function guardarDatos(){
    var imagenesG = document.getElementById('generatedImage');        
    Seleccionados["imagen"] += imagenesG.src;
    Seleccionados["paglink"] = localStorage.getItem('link')
    const title = Seleccionados.titulo;
    const summary = Seleccionados.texto;
    const imagen = Seleccionados.imagen;
    const author = Seleccionados.author;
    const paglink = Seleccionados.paglink; 
    console.log(Seleccionados)
    localStorage.setItem('sel10', JSON.stringify(Seleccionados))
    axios.post(`${AXIOSBACKING}ingresarArticulo`, {title, summary, imagen, author, paglink})//*** HARDCODED URL!!! we must fix this
    /* anterior con localStorage
    if(localStorage.getItem('ListaArticulosExtraidos') !== null){
        var imagenesG = document.getElementById('generatedImage');        
        Seleccionados["imagen"] += imagenesG.src;
        let extraidoLocalS = localStorage.getItem('ListaArticulosExtraidos');
        let convertidoExtraidoLo = JSON.parse(extraidoLocalS);
        convertidoExtraidoLo.push(Seleccionados);
        localStorage.setItem('ListaArticulosExtraidos', JSON.stringify(convertidoExtraidoLo));
    }else{
        listaArticulosObj.push(Seleccionados);
        localStorage.setItem('ListaArticulosExtraidos', JSON.stringify(listaArticulosObj));
    }
        */
    location.href = "./articulos.html";
    
}
Seleccionados["texto"] = localStorage.getItem('resumentTXT');