# Newsletter App 📰

**Newsletter App** is an application designed to **create**, **assemble** and **manage** newsletters efficiently. This tool includes a library of newsletters and articles, and uses **artificial intelligence** to summarize content from external articles and **generate images** when they are not available. Newsletters can include up to 5 articles, and the content can be exported by email.

### ✨Main features✨
- **Newsletter Assembler**: Create newsletters with up to 5 articles.
- **Article Library**: Centralized management of articles and newsletters.
- **Content Generation with AI**:
  - Automatic summary of external articles using AI.
  - Custom image generation with AI for articles without an image.
- **Authentication System**:
  - Login and registration.
  - Two-step verification.
  - Routes protected by JWT (Bearer Token).
### ⚙️**Technologies Used**⚙️
- Backend: **Node.js**, (**Express**, **JWT**, **Bcrypt**, **SEQUELIZE**, **Nodemailer**, **PG**).
- Frontend: **Bootstrap**.
- Database: **PostgreSQL**.
- Dependency management: **npm**.

# 🚀How to start
The proyect have a structure of two folders, **BackAPI** and **Front**. Each one have an start server file and you must to start both. You can follow the next steps by console.

1) Use the package manager [npm](https://www.npmjs.com/) to install all dependencies.

```bash
cd BackAPI #You must to do this with 'Front' folder too.
npm install
```

2) Import the database structure from the *BackAPI/db dump* folder using PostgreSQL.

3) Next step, you must to launch both servers.

### BackAPI
```bash
node starServer.js
```
### Front
```bash
node starServerFront.js
```
4. Open your browser and go to *localhost:3000* (**Front** default port).

Now you can use the entire application.

# 📁Documentation

You can see the API documentation [here]() and the postman collection [here]().
